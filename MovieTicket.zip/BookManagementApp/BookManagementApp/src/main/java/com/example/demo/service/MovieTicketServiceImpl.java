package com.example.demo.service;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exceptions.DuplicateMovieIdExceptions;
import com.example.demo.model.Movie;


import com.example.demo.repository.MovieTicketRepository;

@Service
public class MovieTicketServiceImpl implements MovieTicketService {

	
	@Autowired
	private MovieTicketRepository ticketRepo;
	
	
	@Override
	public List<Movie> getAllMovies() {
		List<Movie> ticketlist = ticketRepo.findAll();
		if(ticketlist !=null && ticketlist.size() >0)
		{
			return ticketlist;
		}
		return null;
	}

	@Override
	public Movie addMovie(Movie book) throws DuplicateMovieIdExceptions {
		
		Optional<Movie> opObj = ticketRepo.findById(book.getMovieId());
		
		if(opObj.isPresent())
		{
			throw new DuplicateMovieIdExceptions();
		}
		return ticketRepo.saveAndFlush(book);
	}

	@Override
	public boolean deleteMovie(int bid) {
		ticketRepo.deleteById(bid);
		return true;
	}

	

}






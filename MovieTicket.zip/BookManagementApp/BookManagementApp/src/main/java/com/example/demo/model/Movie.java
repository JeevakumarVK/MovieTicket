package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Movie 
{
	@Id
	private int movieId;
	String movieName;
	String theatreName;
	int seatsAvl;
	
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
	public int getSeatsAvl() {
		return seatsAvl;
	}
	public void setSeatsAvl(int seatsAvl) {
		this.seatsAvl = seatsAvl;
	}
	
	
	
	
}



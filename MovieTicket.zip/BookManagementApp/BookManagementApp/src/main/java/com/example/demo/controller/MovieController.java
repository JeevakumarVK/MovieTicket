package com.example.demo.controller;

import java.util.List;


import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.DeletedMovieException;
import com.example.demo.exceptions.DuplicateMovieIdExceptions;
import com.example.demo.model.Movie;
import com.example.demo.response.ResponseHandler;
import com.example.demo.service.MovieTicketService;

@RestController
@RequestMapping("api/v1")
public class MovieController 
{
	@Autowired
	private MovieTicketService bs; 
	
	
	@PostMapping("/addMovie")
	public ResponseEntity<?> addBook(@RequestBody Movie book) throws DuplicateMovieIdExceptions
	{
		if(bs.addMovie(book)!=null)
		{
			return new ResponseEntity<Movie>(book, HttpStatus.CREATED);
		}
		return new ResponseEntity<String>("movie is null", HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/getAllMovies")
	public ResponseEntity<?> getBooks() 
	{
		List<Movie> booklist = bs.getAllMovies();
		if(booklist!=null)
		{
			return new ResponseEntity<List<Movie>>(booklist, HttpStatus.OK);
		}
		return new ResponseEntity<String>("movielist is empty", HttpStatus.NO_CONTENT);
	
	}
	
	
	
	@DeleteMapping("/delete/{bid}")
	public ResponseEntity<?> deleteBookById(@PathVariable("bid") int bid) throws DeletedMovieException
	{
		if(bs.deleteMovie(bid))
		{
			return new ResponseEntity<String>("Movie record deleted",HttpStatus.OK);
		}
		return new ResponseEntity<String>("movie could not be deleted", HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	
	
	//GET fetching
	//POST sending
	//PUT updating
	//DELETE deleting
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

package com.example.demo.service;

import java.util.List;


import com.example.demo.exceptions.DuplicateMovieIdExceptions;
import com.example.demo.model.Movie;


public interface MovieTicketService 
{
	public List<Movie> getAllMovies();
	
	public Movie addMovie(Movie book) throws DuplicateMovieIdExceptions;
	
	public boolean deleteMovie(int bid);
	
	
	
	
	
	
	

}
